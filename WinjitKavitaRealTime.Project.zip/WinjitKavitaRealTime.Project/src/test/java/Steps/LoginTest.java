package Steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginTest {

	
	
	@Given("User Launching the application")
	public void user_launching_the_application() {
	   
	}

	@When("User login the application")
	public void user_login_the_application() {
	   
	}

	@Then("User successfully on the home page")
	public void user_successfully_on_the_home_page() {
	   
	}

	
	@Then("user logout the application")
	public void user_logout_the_application() {
	    
	}

}
